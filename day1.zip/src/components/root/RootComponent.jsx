import React, { Component } from 'react';

// import ComponentOne from '../2_multi-components/ComponentOne';
// import ComponentTwo from '../2_multi-components/ComponentTwo';

// import ComponentOne from '../3_components-with-css/ComponentOne';
// import ComponentTwo from '../3_components-with-css/ComponentTwo';

// import ComponentOne from '../4_external-css/comp-one/ComponentOne';
// import ComponentTwo from '../4_external-css/comp-two/ComponentTwo';

// import ComponentOne from '../5_css-modules/comp-one/ComponentOne';
// import ComponentTwo from '../5_css-modules/comp-two/ComponentTwo';

// import ComponentWithState from '../6_comp-state/ComponentWithState';
// import ComponentWithProps from '../7_comp-props/ComponentWithProps';
// import ComponentWithBehavior from '../8_comp-behavior/ComponentWithBehavior';
// import ClassVsFuncComponent from '../9_class-vs-func/ClassVsFuncComponent';
// import EventComponent from '../10_synthetic-events/EventComponent';
// import CounterAssignment from '../11_Assignment/CounterAssignment';
import ControlledAndUncontrolled from '../12_controlled-vs-uncontrolled/ControlledAndUncontrolled';
import CalculatorAssignment from '../11_Assignment/CalculatorAssignment';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                {/* <ComponentOne />
                <ComponentTwo /> */}

                {/* <ComponentWithState /> */}
                {/* <ComponentWithProps name={"Synechron"} address={{ city: "Pune", state: "MH" }} display={function () {
                    alert("clicked....");
                }} /> */}
                {/* <ComponentWithBehavior /> */}
                {/* <ClassVsFuncComponent /> */}
                {/* <EventComponent /> */}
                {/* <CounterAssignment /> */}
                {/* <ControlledAndUncontrolled /> */}
                <CalculatorAssignment />
            </div>
        );
    }
}

export default RootComponent;