// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         // return "Hello"; 
//         // return 1000;
//         // return true; 
//         // return Symbol("Hello"); 
//         // return { id: 1 };        // Not Allowed to return objects
//     }
// }

// export default HelloComponent;

// ----------------------------------------------------

// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         return <h1 className="abc">Hello World!</h1>;   // JSX Element
//     }
// }

// export default HelloComponent;

// ----------------------------------------------------

// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         return (
//             <div>
//                 <h1 className="abc">Hello World!</h1>
//                 <h1 className="abc">Hello World Again!</h1>
//             </div>   // return only one JSX Element
//         );
//     }
// }

// export default HelloComponent;

// ---------------------------------------------------- Stateful Components / Container Components
// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         return (
//             <React.Fragment>
//                 <h1 className="abc">Hello World!</h1>
//                 <h1 className="abc">Hello World Again!</h1>
//             </React.Fragment>   // return only one JSX Element
//         );
//     }
// }

// export default HelloComponent;

// ---------------------------------------------------- Stateful Components / Container Components
// import React, { Component, Fragment } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return (
//             <Fragment>
//                 <h1 className="abc">Hello World!</h1>
//                 <h1 className="abc">Hello World Again!</h1>
//             </Fragment>   // return only one JSX Element
//         );
//     }
// }

// export default HelloComponent;

// ---------------------------------------------------- Stateless Components / Presentation Components
import React from 'react';

// function HelloComponent() {
//     return (
//         <React.Fragment>
//             <h1 className="abc">Hello World!</h1>
//             <h1 className="abc">Hello World Again!</h1>
//         </React.Fragment>   // return only one JSX Element
//     );
// }

// const HelloComponent = function () {
//     return (
//         <React.Fragment>
//             <h1 className="abc">Hello World! - Using Anonymous Function</h1>
//             <h1 className="abc">Hello World Again!</h1>
//         </React.Fragment>   // return only one JSX Element
//     );
// }

// const HelloComponent = () => {
//     return (
//         <React.Fragment>
//             <h1 className="abc">Hello World! - Using Arrow Function</h1>
//             <h1 className="abc">Hello World Again!</h1>
//         </React.Fragment>   // return only one JSX Element
//     );
// }

// const HelloComponent = () => (
//     <React.Fragment>
//         <h1 className="abc">Hello World! - Using Single line Arrow Function</h1>
//         <h1 className="abc">Hello World Again!</h1>
//     </React.Fragment>   // return only one JSX Element
// );

const HelloComponent = () => (
    <div className="container">
        <h1 className="abc">Hello World! - Using Single line Arrow Function</h1>
        <h1 className="text-info">Hello World Again!</h1>
    </div>
);

export default HelloComponent;