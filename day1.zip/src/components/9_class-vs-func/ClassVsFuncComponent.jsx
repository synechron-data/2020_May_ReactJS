/* eslint-disable */
import React, { Component } from 'react';

class ComponentOne extends Component {
    render() {
        console.log(this.state);
        console.log(this.props);
        return (
            <div>
                <h2 className="text-info">Using Class Syntax</h2>
            </div>
        );
    }
}

// Functional / Stateless / Presentational
const ComponentTwo = () => {
    // console.log(this.state);
    // console.log(this.props);
    return (
        <div>
            <h2 className="text-info">Using Arrow Syntax</h2>
        </div>
    );
};

const ComponentThree = (props) => {
    console.log(props);
    return (
        <div>
            <h2 className="text-info">Using Arrow Syntax</h2>
        </div>
    );
};

const ComponentFour = ({ id, name }) => {
    console.log(id);
    console.log(name);
    return (
        <div>
            <h2 className="text-info">Using Arrow Syntax</h2>
        </div>
    );
};

const ComponentFive = ({ id, name, ...address }) => {
    console.log(id);
    console.log(name);
    console.log(address);
    return (
        <div>
            <h2 className="text-info">Using Arrow Syntax</h2>
        </div>
    );
};

class ClassVsFuncComponent extends Component {
    render() {
        return (
            <div>
                {/* <ComponentOne /> */}
                {/* <ComponentTwo /> */}
                {/* <ComponentThree id={1} name={"Manish"} city={"Pune"} state={"MH"} /> */}
                {/* <ComponentFour id={1} name={"Manish"} city={"Pune"} state={"MH"} /> */}
                <ComponentFive id={1} name={"Manish"} city={"Pune"} state={"MH"} pin={411021}/>
            </div>
        );
    }
}

export default ClassVsFuncComponent;