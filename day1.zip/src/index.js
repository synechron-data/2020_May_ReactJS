// import React from 'react';
// import ReactDOM from 'react-dom';
// import HelloComponent from './components/1_FirstComponent/HelloComponent';

// ReactDOM.render(<HelloComponent />, document.getElementById('root'));

// // ---------------------------------------------------- Using BS 4
// // npm i bootstrap popper.js jquery
// // npm i -D node-sass

// import 'bootstrap/scss/bootstrap.scss';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import 'bootstrap';

// import HelloComponent from './components/1_FirstComponent/HelloComponent';

// ReactDOM.render(<HelloComponent />, document.getElementById('root'));

// // ---------------------------------------------------- Multiple Components
// import 'bootstrap/scss/bootstrap.scss';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import 'bootstrap';
// import ComponentOne from './components/2_multi-components/ComponentOne';
// import ComponentTwo from './components/2_multi-components/ComponentTwo';

// // ReactDOM.render(<ComponentOne />, document.getElementById('root1'));
// // ReactDOM.render(<ComponentTwo />, document.getElementById('root2'));

// // ReactDOM.render(<React.Fragment>
// //   <ComponentOne />
// //   <ComponentTwo />
// // </React.Fragment>, document.getElementById('root'));

// ReactDOM.render([<ComponentOne />, <ComponentTwo />], document.getElementById('root'));


// ---------------------------------------------------- Using Root Component
import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';
import RootComponent from './components/root/RootComponent';

ReactDOM.render(<RootComponent />, document.getElementById('root'));
