import React, { Component, useState } from 'react';

class UsingClass extends Component {
    constructor(props) {
        super(props);
        this.state = { count: 0 };
    }

    handleClick() {
        this.setState({ count: this.state.count + 1 });
    }

    render() {
        return (
            <div>
                <h2 className="text-info">Count: {this.state.count}</h2>
                <button className="btn btn-primary" onClick={this.handleClick.bind(this)}>Click</button>
            </div>
        );
    }
}

const UsingFunction = () => {
    const [count, setCount] = useState(0);

    return (
        <div>
            <h2 className="text-info">Count: {count}</h2>
            <button className="btn btn-primary" onClick={() => setCount(count + 1)}>+</button>
            <button className="btn btn-primary" onClick={() => setCount(count - 1)}>-</button>
        </div>
    );
};

class StateHook extends Component {
    render() {
        return (
            <div>
                <UsingClass />
                <UsingFunction />
            </div>
        );
    }
}


export default StateHook;