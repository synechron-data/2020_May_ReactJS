/* eslint-disable */
import React, { Component } from 'react';

import CalculatorAssignment from '../1_Assignments/CalculatorAssignment';
import PropTypesDemo from '../2_prop-types/PropTypesDemo';
import ErrorHandler from '../common/ErrorHandler';
import ListRoot from '../3_list/ListComponent';
import AjaxComponent from '../4_ajax/AjaxComponent';
import ContextAPIDemoComponent from '../5_context-api/ContextAPIDemo';
import StateHook from '../6_hooks/StateHook';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <CalculatorAssignment /> */}
                    {/* <PropTypesDemo /> */}
                    {/* <ListRoot /> */}
                    {/* <AjaxComponent /> */}
                    {/* <ContextAPIDemoComponent /> */}
                    <StateHook />
                </ErrorHandler>
            </div>
        );
    }

}

export default RootComponent;