import React, { Component } from 'react';
import DataTable from '../common/DataTable';
import postAPIClient from '../../services/posts.service';

const { Provider, Consumer } = React.createContext();

class ChildComponentOne extends Component {
    render() {
        return (
            <div>
                <h3 className="text-info">Child One</h3>
                <ChildComponentTwo />
            </div>
        );
    }
}

class ChildComponentTwo extends Component {
    render() {
        return (
            <div>
                <h3 className="text-info">Child Two</h3>
                <Consumer>
                    {
                        (data) => (
                            <DataTable items={data}>
                                <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
                            </DataTable>
                        )
                    }
                </Consumer>
            </div>
        );
    }
}

class ContextAPIDemoComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading Data, please wait...." };
    }

    render() {
        return (
            <React.Fragment>
                <div className="row">
                    <h3 className="text-info">Main Component</h3>
                </div>
                <div className="row">
                    <h4 className="text-warning text-uppercase font-weight-bold">{this.state.message}</h4>
                </div>
                <Provider value={this.state.posts}>
                    <ChildComponentOne />
                </Provider>
            </React.Fragment>
        );
    }

    componentDidMount() {
        postAPIClient.getAllPosts().then((result) => {
            this.setState({ posts: [...result], message: "" });
        }).catch((eMsg) => {
            this.setState({ posts: [], message: eMsg });
        });
    }
}

export default ContextAPIDemoComponent;

// ---------------------------------------------------------------------------
// import React, { Component } from 'react';
// import DataTable from '../common/DataTable';
// import postAPIClient from '../../services/posts.service';

// class ChildComponentOne extends Component {
//     render() {
//         return (
//             <div>
//                 <h3 className="text-info">Child One</h3>
//                 <ChildComponentTwo data={this.props.data}/>
//             </div>
//         );
//     }
// }

// class ChildComponentTwo extends Component {
//     render() {
//         return (
//             <div>
//                 <h3 className="text-info">Child Two</h3>
//                 <DataTable items={this.props.data}>
//                     <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
//                 </DataTable>
//             </div>
//         );
//     }
// }

// class ContextAPIDemoComponent extends Component {
//     constructor(props) {
//         super(props);
//         this.state = { posts: [], message: "Loading Data, please wait...." };
//     }

//     render() {
//         return (
//             <React.Fragment>
//                 <div className="row">
//                     <h3 className="text-info">Main Component</h3>
//                 </div>
//                 <div className="row">
//                     <h4 className="text-warning text-uppercase font-weight-bold">{this.state.message}</h4>
//                 </div>
//                 <ChildComponentOne data={this.state.posts}/>
//             </React.Fragment>
//         );
//     }

//     componentDidMount() {
//         postAPIClient.getAllPosts().then((result) => {
//             this.setState({ posts: [...result], message: "" });
//         }).catch((eMsg) => {
//             this.setState({ posts: [], message: eMsg });
//         });
//     }
// }

// export default ContextAPIDemoComponent;