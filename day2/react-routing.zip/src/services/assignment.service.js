const url = "http://localhost:8000/products";

const productsClient = {
    getAllProducts: function () {
        var promise = new Promise((resolve, reject) => {
            return fetch(url).then((res) => {
                var result = res.json();
                result.then((jResult) => {
                    setTimeout(() => {
                        resolve(jResult);
                    }, 2000);
                }, (err) => {
                    reject("JSON Parse Error");
                });
            }).catch((err) => {
                reject("Error connecting to the API");
            });
        });

        return promise;
    },

    insertProduct: function (p) {
        const request = new Request(url, {
            method: 'POST',
            headers: new Headers({
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(p)
        });

        var promise = new Promise((resolve, reject) => {
            return fetch(request).then((res) => {
                var result = res.json();
                result.then((jResult) => {
                    resolve(jResult);
                }, (err) => {
                    reject("JSON Parse Error");
                });
            }).catch((err) => {
                reject("Error connecting to the API");
            });
        });

        return promise;
    }
}

export default productsClient;