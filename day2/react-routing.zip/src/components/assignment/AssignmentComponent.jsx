import React, { Component } from 'react';
import DataTable from '../common/DataTable';
import productsClient from '../../services/assignment.service';
import LoaderAnimation from '../common/LoaderAnimation';

class AssignmentComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { products: [], message: "Loading Data, please wait..." };
    }

    render() {
        return (
            <React.Fragment>
                {
                    this.state.message ?
                        <div className="pt-5">
                            <LoaderAnimation />
                        </div> :
                        <DataTable items={this.state.products}>
                            <h4 className="text-primary text-uppercase font-weight-bold">Products Table</h4>
                        </DataTable>
                }
            </React.Fragment>
        );
    }

    componentDidMount() {
        productsClient.getAllProducts().then((data) => {
            this.setState({ products: [...data], message: "" });
        }, (eMsg) => {
            this.setState({ message: eMsg });
        })
    }
}

export default AssignmentComponent;