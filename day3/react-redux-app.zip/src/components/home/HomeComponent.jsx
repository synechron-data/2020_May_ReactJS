import React, { Component } from 'react';

class HomeComponent extends Component {
    render() {
        return (
            <div>
                <h1 className="text-info">Home Component</h1>
                <h4 className="text-warning">This is a Simple, React Redux Application</h4>
                <h1>Added using HOC: {this.props.data}</h1>
            </div>
        );
    }
}

var obj = {
    data: "Hello from HOC"
}

var MyHOC = CComponent => class extends React.Component {
    componentDidMount() {
        this.setState({ data: obj.data });
    }

    render(){
        return <CComponent {...this.props} {...this.state} />
    }
}

// export default HomeComponent;
export default MyHOC(HomeComponent);
