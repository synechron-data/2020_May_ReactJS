import * as actionTypes from './actionTypes';
import productsAPIClient from '../services/product.service';
import history from '../history';

function loadProductsRequested(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_REQUESTED,
        payload: { flag: false, message: msg }
    };
}

function loadProductsSuccess(products, msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_SUCCESS,
        payload: { flag: true, message: msg, data: products }
    };
}

function loadProductsFailed(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_FAILED,
        payload: { flag: true, message: msg, data: [] }
    };
}

// A thunk is a function that returns another function that takes parameters dispatch
export function loadProducts() {
    return function (dispatch) {
        dispatch(loadProductsRequested("Request Started..."));

        productsAPIClient.getAllProducts().then((products) => {
            setTimeout(() => {
                dispatch(loadProductsSuccess(products, "Request Complteted Successfully"))
            }, 1000);
        }, (eMsg) => {
            dispatch(loadProductsFailed(eMsg));
        });
    }
}

function insertProductSuccess(product, msg) {
    return {
        type: actionTypes.INSERT_PRODUCT_SUCCESS,
        payload: { flag: true, message: msg, data: product }
    };
}

export function insertProduct(product) {
    return function (dispatch) {
        productsAPIClient.insertProduct(product).then((insertedProduct) => {
            dispatch(insertProductSuccess(insertedProduct, "Record Inserted Successfully"));
            history.push("/products");
        }, (eMsg) => {
            console.log(eMsg);
        });
    }
}

function updateProductSuccess(product, msg) {
    return {
        type: actionTypes.UPDATE_PRODUCT_SUCCESS,
        payload: { flag: true, message: msg, data: product }
    };
}

export function updateProduct(product) {
    return function (dispatch) {
        productsAPIClient.updateProduct(product).then((updatedProduct) => {
            dispatch(updateProductSuccess(updatedProduct, "Record Updated Successfully"));
            history.push("/products");
        }, (eMsg) => {
            console.log(eMsg);
        });
    }
}

function deleteProductSuccess(product, msg) {
    return {
        type: actionTypes.DELETE_PRODUCT_SUCCESS,
        payload: { flag: true, message: msg, data: product }
    };
}

export function deleteProduct(product) {
    return function (dispatch) {
        productsAPIClient.deleteProduct(product).then(() => {
            dispatch(deleteProductSuccess(product, "Record Deleted Successfully"));
        }, (eMsg) => {
            console.log(eMsg);
        });
    }
}