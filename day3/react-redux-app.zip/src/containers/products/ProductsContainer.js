import React, { Component } from 'react';
import { connect } from 'react-redux';

import LoaderAnimation from '../../components/common/LoaderAnimation';
import ProductListComponent from '../../components/products/ProductListComponent';

import * as productActions from '../../actions/productActions';
import AddProductButton from '../../components/products/AddProductButton';

class ProductsContainer extends Component {
    constructor(props) {
        super(props);
        this.deleteProduct = this.deleteProduct.bind(this);
    }

    deleteProduct(p, e) {
        this.props.deleteProduct(p);
    }

    render() {
        return (
            <React.Fragment>
                {
                    this.props.flag ?
                        <React.Fragment>
                            <br /><br />
                            <AddProductButton />
                            <br /><br />
                            <ProductListComponent products={this.props.products} onDelete={this.deleteProduct} />
                        </React.Fragment>
                        :
                        <div className="pt-5">
                            <LoaderAnimation />
                        </div>
                }
            </React.Fragment>
        );
    }

    componentDidMount() {
        this.props.loadProducts();
    }
}

function mapStateToProps(state, ownProps) {
    return {
        products: state.productReducer.products,
        message: state.productReducer.status,
        flag: state.productReducer.flag
    };
}

function mapDispatchToProps(dispatch) {
    return {
        loadProducts: () => { dispatch(productActions.loadProducts()); },
        deleteProduct: (p) => { dispatch(productActions.deleteProduct(p)); }
    };
}

// export default connect(mapStateToProps, mapDispatchToProps)(ProductsContainer);
var componentEnhancer = connect(mapStateToProps, mapDispatchToProps);
var enhancedProductsContainer = componentEnhancer(ProductsContainer);
export default enhancedProductsContainer;